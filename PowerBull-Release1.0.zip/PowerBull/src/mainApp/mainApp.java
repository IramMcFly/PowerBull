package mainApp;

import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import extraApps.addCar;
import screens.articleMenu;
import extraApps.detailsArticle;
import screens.employeeMenu;
import screens.vendingMenu;
import screens.ventasMenu;

public class mainApp extends javax.swing.JFrame {

    public Connection conexion;
    public String userID = "";
    public String puesto = "";
    private DefaultTableModel cartModel;  // Modelo para CartTable
    public int selectedCarID;

    public mainApp(Connection conexionRecibida, String EmpleadoID, String EmpleadoPuesto) {
        //cargar datos
        this.conexion = conexionRecibida;
        this.userID = EmpleadoID;
        this.puesto = EmpleadoPuesto;

        initComponents();
        this.setLocationRelativeTo(null);
        //this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        ProfileSelector(puesto);
        loadTitle();
        loadComboBox();

        yearComboBox.setSelectedIndex(-1);
        brandComboBox.setEnabled(false);
        brandComboBox.setSelectedIndex(-1);
        modelComboBox.setEnabled(false);
        modelComboBox.setSelectedIndex(-1);

        applyButton.setEnabled(false);
        searchField.setEnabled(false);

        piecePanel1.setVisible(false);
        piecePanel2.setVisible(false);
        piecePanel3.setVisible(false);

        cartModel = (DefaultTableModel) cartTable.getModel();
        cartModel.setRowCount(0);  // Limpiar el carrito inicialmente

        initializePopupMenu();
        proceedPaymentButton.setEnabled(false);
    }

    private void initializePopupMenu() {
        // Crear el menú emergente
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem deleteItem = new JMenuItem("Eliminar artículo");

        // Añadir la acción de eliminar al menú
        deleteItem.addActionListener((ActionEvent e) -> {
            deleteSelectedArticle();
        });
        popupMenu.add(deleteItem);

        // Añadir el listener de clic derecho a la tabla
        cartTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e) && cartTable.getSelectedRow() != -1) {
                    popupMenu.show(cartTable, e.getX(), e.getY());
                }
            }
        });
    }

    private void deleteSelectedArticle() {
        int selectedRow = cartTable.getSelectedRow();
        if (selectedRow != -1) {
            // Remover la fila seleccionada del modelo de la tabla
            DefaultTableModel model = (DefaultTableModel) cartTable.getModel();
            model.removeRow(selectedRow);

            // Actualizar el subtotal después de eliminar un artículo
            updateSubtotal();
        }
    }

    private void ProfileSelector(String pPuesto) {
        if (null != pPuesto) {
            switch (pPuesto) {
                case "Vendedor" -> {
                    managerMenu.setVisible(false);
                    developerMenu.setVisible(false);
                }
                case "DevOps" -> {
                    panelMainApp.setVisible(false);
                    managerMenu.setText("Menu de Gerencia");
                    managerMenu.setVisible(false);
                }

                case "Gerente" -> {
                    developerMenu.setVisible(false);
                }

                default -> {
                }
            }
        }

    }

    public mainApp() {
        //unused
    }

    private void loadTitle() {
        String nombreEmpleado = "";

        try {
            String sql = "SELECT nombre, apellido_paterno FROM empleados WHERE ID_Empleado = ?";
            PreparedStatement pstmt = conexion.prepareStatement(sql);
            pstmt.setString(1, userID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                nombreEmpleado = rs.getString("nombre") + " " + rs.getString("apellido_paterno");
            }

            this.setTitle("Sesión iniciada como: " + nombreEmpleado + " - " + puesto);

        } catch (SQLException e) {
            this.setTitle("Sesión iniciada - Error al cargar nombre");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelMainApp = new javax.swing.JPanel();
        yearLabel = new javax.swing.JLabel();
        brandLabel = new javax.swing.JLabel();
        modelLabel = new javax.swing.JLabel();
        yearComboBox = new javax.swing.JComboBox<>();
        brandComboBox = new javax.swing.JComboBox<>();
        modelComboBox = new javax.swing.JComboBox<>();
        searchField = new javax.swing.JTextField();
        searchLabel = new javax.swing.JLabel();
        applyButton = new javax.swing.JButton();
        piecePanel1 = new javax.swing.JPanel();
        image1 = new javax.swing.JLabel();
        name_product1 = new javax.swing.JLabel();
        category1 = new javax.swing.JLabel();
        price1 = new javax.swing.JLabel();
        stocklabel1 = new javax.swing.JLabel();
        part_number1 = new javax.swing.JLabel();
        addButton1 = new javax.swing.JButton();
        piecePanel2 = new javax.swing.JPanel();
        image2 = new javax.swing.JLabel();
        name_product2 = new javax.swing.JLabel();
        category2 = new javax.swing.JLabel();
        price2 = new javax.swing.JLabel();
        stocklabel2 = new javax.swing.JLabel();
        part_number2 = new javax.swing.JLabel();
        addButton2 = new javax.swing.JButton();
        piecePanel3 = new javax.swing.JPanel();
        image3 = new javax.swing.JLabel();
        name_product3 = new javax.swing.JLabel();
        category3 = new javax.swing.JLabel();
        price3 = new javax.swing.JLabel();
        stocklabel3 = new javax.swing.JLabel();
        part_number3 = new javax.swing.JLabel();
        addButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        cartTable = new javax.swing.JTable();
        subtotalLabel = new javax.swing.JLabel();
        proceedPaymentButton = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        managerMenu = new javax.swing.JMenu();
        empleadosMenu = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        articulosMenu = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        ventasMenu = new javax.swing.JMenuItem();
        developerMenu = new javax.swing.JMenu();
        newCarMenu = new javax.swing.JMenuItem();
        aboutMenu = new javax.swing.JMenu();
        logOut = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Store Manager");

        yearLabel.setText("Año");

        brandLabel.setText("Marca");

        modelLabel.setText("Modelo");

        yearComboBox.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        yearComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearComboBoxActionPerformed(evt);
            }
        });

        brandComboBox.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        brandComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brandComboBoxActionPerformed(evt);
            }
        });

        modelComboBox.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        modelComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modelComboBoxActionPerformed(evt);
            }
        });

        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchFieldKeyReleased(evt);
            }
        });

        searchLabel.setText("Buscar pieza");

        applyButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        applyButton.setText("Aplicar");
        applyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyButtonActionPerformed(evt);
            }
        });

        piecePanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        name_product1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        name_product1.setText("NombrePieza");
        name_product1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                name_product1MouseClicked(evt);
            }
        });

        category1.setText("CategoriaPieza");

        price1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price1.setText("PrecioPieza");

        stocklabel1.setText("Stock Pieza:");

        part_number1.setText("numero parte");

        addButton1.setText("Agregar al Carrito");
        addButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout piecePanel1Layout = new javax.swing.GroupLayout(piecePanel1);
        piecePanel1.setLayout(piecePanel1Layout);
        piecePanel1Layout.setHorizontalGroup(
            piecePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(piecePanel1Layout.createSequentialGroup()
                .addGroup(piecePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(piecePanel1Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(piecePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stocklabel1)
                            .addComponent(name_product1)
                            .addComponent(price1)
                            .addComponent(part_number1)))
                    .addGroup(piecePanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(category1)
                        .addGap(64, 64, 64)
                        .addComponent(addButton1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(image1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        piecePanel1Layout.setVerticalGroup(
            piecePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(piecePanel1Layout.createSequentialGroup()
                .addGroup(piecePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(piecePanel1Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(name_product1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(part_number1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(stocklabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(piecePanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(category1)
                            .addComponent(addButton1)))
                    .addGroup(piecePanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(image1, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        piecePanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        name_product2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        name_product2.setText("NombrePieza");
        name_product2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                name_product2MouseClicked(evt);
            }
        });

        category2.setText("CategoriaPieza");

        price2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price2.setText("PrecioPieza");

        stocklabel2.setText("Stock Pieza:");

        part_number2.setText("numero parte");

        addButton2.setText("Agregar al Carrito");
        addButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout piecePanel2Layout = new javax.swing.GroupLayout(piecePanel2);
        piecePanel2.setLayout(piecePanel2Layout);
        piecePanel2Layout.setHorizontalGroup(
            piecePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(piecePanel2Layout.createSequentialGroup()
                .addGroup(piecePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(piecePanel2Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(piecePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stocklabel2)
                            .addComponent(name_product2)
                            .addComponent(price2)
                            .addComponent(part_number2)))
                    .addGroup(piecePanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(category2)
                        .addGap(60, 60, 60)
                        .addComponent(addButton2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(image2, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        piecePanel2Layout.setVerticalGroup(
            piecePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(piecePanel2Layout.createSequentialGroup()
                .addGroup(piecePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(piecePanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(name_product2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(part_number2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(price2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(stocklabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 143, Short.MAX_VALUE)
                        .addGroup(piecePanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(category2)
                            .addComponent(addButton2)))
                    .addGroup(piecePanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(image2, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        piecePanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        name_product3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        name_product3.setText("NombrePieza");
        name_product3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                name_product3MouseClicked(evt);
            }
        });

        category3.setText("CategoriaPieza");

        price3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price3.setText("PrecioPieza");

        stocklabel3.setText("Stock Pieza:");

        part_number3.setText("numero parte");

        addButton3.setText("Agregar al Carrito");
        addButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout piecePanel3Layout = new javax.swing.GroupLayout(piecePanel3);
        piecePanel3.setLayout(piecePanel3Layout);
        piecePanel3Layout.setHorizontalGroup(
            piecePanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(piecePanel3Layout.createSequentialGroup()
                .addGroup(piecePanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(piecePanel3Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(piecePanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(stocklabel3)
                            .addComponent(name_product3)
                            .addComponent(price3)
                            .addComponent(part_number3)))
                    .addGroup(piecePanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(category3)
                        .addGap(59, 59, 59)
                        .addComponent(addButton3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(image3, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        piecePanel3Layout.setVerticalGroup(
            piecePanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(piecePanel3Layout.createSequentialGroup()
                .addGroup(piecePanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(piecePanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(name_product3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(piecePanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(piecePanel3Layout.createSequentialGroup()
                                .addComponent(part_number3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(price3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(stocklabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(category3))
                            .addGroup(piecePanel3Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(addButton3))))
                    .addGroup(piecePanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(image3, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        cartTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Numero Parte", "Articulo", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(cartTable);

        subtotalLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        subtotalLabel.setText("Subtotal");

        proceedPaymentButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        proceedPaymentButton.setText("Proceder al pago");
        proceedPaymentButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                proceedPaymentButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelMainAppLayout = new javax.swing.GroupLayout(panelMainApp);
        panelMainApp.setLayout(panelMainAppLayout);
        panelMainAppLayout.setHorizontalGroup(
            panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMainAppLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(piecePanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(piecePanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(piecePanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(searchLabel)
                        .addComponent(searchField)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMainAppLayout.createSequentialGroup()
                            .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(yearLabel)
                                .addComponent(yearComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(brandComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(brandLabel))
                            .addGap(18, 18, 18)
                            .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelMainAppLayout.createSequentialGroup()
                                    .addComponent(modelComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(applyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(modelLabel)))
                        .addGroup(panelMainAppLayout.createSequentialGroup()
                            .addComponent(subtotalLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(proceedPaymentButton, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55))
        );
        panelMainAppLayout.setVerticalGroup(
            panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMainAppLayout.createSequentialGroup()
                .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMainAppLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(yearLabel)
                            .addComponent(brandLabel)
                            .addComponent(modelLabel))
                        .addGap(3, 3, 3)
                        .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(brandComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(applyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(modelComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yearComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(searchLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelMainAppLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(subtotalLabel)
                            .addComponent(proceedPaymentButton, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelMainAppLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(piecePanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(piecePanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(piecePanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(86, Short.MAX_VALUE))
        );

        managerMenu.setText("Menu del Gerente");

        empleadosMenu.setText("Empleados");
        empleadosMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empleadosMenuActionPerformed(evt);
            }
        });
        managerMenu.add(empleadosMenu);
        managerMenu.add(jSeparator1);

        articulosMenu.setText("Articulos");
        articulosMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                articulosMenuActionPerformed(evt);
            }
        });
        managerMenu.add(articulosMenu);
        managerMenu.add(jSeparator2);

        ventasMenu.setText("Ventas");
        ventasMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventasMenuActionPerformed(evt);
            }
        });
        managerMenu.add(ventasMenu);

        menuBar.add(managerMenu);

        developerMenu.setText("Menu de Desarrollador");

        newCarMenu.setText("Nuevo Auto");
        newCarMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newCarMenuActionPerformed(evt);
            }
        });
        developerMenu.add(newCarMenu);

        menuBar.add(developerMenu);

        aboutMenu.setText("Acerca De");
        aboutMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aboutMenuMouseClicked(evt);
            }
        });
        menuBar.add(aboutMenu);

        logOut.setText("Salir");
        logOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logOutMouseClicked(evt);
            }
        });
        menuBar.add(logOut);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelMainApp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelMainApp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void aboutMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aboutMenuMouseClicked
        aboutFrame aF = new aboutFrame();
        aF.setVisible(true);
    }//GEN-LAST:event_aboutMenuMouseClicked

    private void empleadosMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empleadosMenuActionPerformed
        employeeMenu eS = new employeeMenu(conexion);
        eS.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_empleadosMenuActionPerformed

    private void logOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logOutMouseClicked
        try {
            conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(mainApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.exit(0);
    }//GEN-LAST:event_logOutMouseClicked

    private void addToCart(String numPart, String nombre, double precio) {
        DefaultTableModel model = (DefaultTableModel) cartTable.getModel();
        model.addRow(new Object[]{numPart, nombre, precio});
        updateSubtotal();
    }

    private void updateSubtotal() {

        double subtotal = 0.0;
        DefaultTableModel model = (DefaultTableModel) cartTable.getModel();

        // Calcular el nuevo subtotal sumando los precios en la tabla
        for (int i = 0; i < model.getRowCount(); i++) {
            subtotal += (double) model.getValueAt(i, 2); // Asumiendo que el precio está en la segunda columna
        }

        // Actualizar el subtotal en la etiqueta correspondiente
        subtotalLabel.setText("Subtotal: $" + subtotal);
        if (subtotal != 0) {
            proceedPaymentButton.setEnabled(true);
        } else {
            proceedPaymentButton.setEnabled(false);
        }

    }

    private void loadComboBox() {
        // Cargar años primero
        try {
            String sql = "SELECT DISTINCT anio FROM autos ORDER BY anio";
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                yearComboBox.addItem(String.valueOf(rs.getInt("anio")));

            }
        } catch (SQLException e) {
        }
    }

    private void brandComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brandComboBoxActionPerformed
        // Limpiar el ComboBox de modelos
        modelComboBox.removeAllItems();

        try {
            String selectedBrand = (String) brandComboBox.getSelectedItem();
            String selectedYearString = (String) yearComboBox.getSelectedItem();

            // Asegúrate de que el año no sea nulo y conviértelo a Integer
            if (selectedYearString != null) {
                int selectedYear = Integer.parseInt(selectedYearString);
                String sql = "SELECT modelo FROM autos a INNER JOIN marca m ON a.id_marca = m.id_marca WHERE m.nombre_marca = ? AND a.anio = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setString(1, selectedBrand);
                pstmt.setInt(2, selectedYear);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    modelComboBox.addItem(rs.getString("modelo"));
                }
            }
        } catch (SQLException | NumberFormatException e) {

        }

        modelComboBox.setEnabled(true);
        modelComboBox.setSelectedIndex(-1);
    }//GEN-LAST:event_brandComboBoxActionPerformed

    private void yearComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearComboBoxActionPerformed
        // Limpiar el ComboBox de marcas y modelos
        brandComboBox.removeAllItems();
        modelComboBox.removeAllItems();

        try {
            String selectedYearString = (String) yearComboBox.getSelectedItem();

            // Asegúrate de que el año no sea nulo y conviértelo a Integer
            if (selectedYearString != null) {
                int selectedYear = Integer.parseInt(selectedYearString);
                String sql = "SELECT DISTINCT m.nombre_marca FROM autos a INNER JOIN marca m ON a.id_marca = m.id_marca WHERE a.anio = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setInt(1, selectedYear);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    brandComboBox.addItem(rs.getString("nombre_marca"));
                }
            }
        } catch (SQLException | NumberFormatException e) {
            //unuseds
        }
        brandComboBox.setEnabled(true);
        brandComboBox.setSelectedIndex(-1);
        modelComboBox.setEnabled(false);
        modelComboBox.setSelectedIndex(-1);
        applyButton.setEnabled(false);
        searchField.setEnabled(false);
        piecePanel1.setVisible(false);
        piecePanel2.setVisible(false);
        piecePanel3.setVisible(false);

    }//GEN-LAST:event_yearComboBoxActionPerformed

    private void articulosMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_articulosMenuActionPerformed
        articleMenu aM = new articleMenu(conexion);
        this.dispose();
        aM.setVisible(true);
        applyButton.setEnabled(false);
    }//GEN-LAST:event_articulosMenuActionPerformed

    private void modelComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modelComboBoxActionPerformed
        applyButton.setEnabled(true);
        piecePanel1.setVisible(false);
        piecePanel2.setVisible(false);
        piecePanel3.setVisible(false);
    }//GEN-LAST:event_modelComboBoxActionPerformed

    private void applyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyButtonActionPerformed
        String selectedYear = (String) yearComboBox.getSelectedItem();
        String selectedBrand = (String) brandComboBox.getSelectedItem();
        String selectedModel = (String) modelComboBox.getSelectedItem();

        if (selectedYear != null && selectedBrand != null && selectedModel != null) {
            try {
                // Consulta para obtener el ID del vehículo basado en el año, marca y modelo seleccionados
                String sql = "SELECT id_auto FROM autos a "
                        + "INNER JOIN marca m ON a.id_marca = m.id_marca "
                        + "WHERE a.anio = ? AND m.nombre_marca = ? AND a.modelo = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setInt(1, Integer.parseInt(selectedYear));
                pstmt.setString(2, selectedBrand);
                pstmt.setString(3, selectedModel);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    int idAuto = rs.getInt("id_auto");

                    // Imprimir y/o guardar el ID
                    System.out.println("ID del Vehículo: " + idAuto);
                    selectedCarID = idAuto;
                    searchField.setEnabled(true);
                    // Aquí podrías hacer otra operación como insertarlo en otra tabla o almacenarlo en una variable global
                } else {
                    System.out.println("Vehículo no encontrado.");
                }
            } catch (SQLException e) {
            }
        } else {
            System.out.println("Por favor selecciona año, marca y modelo.");
        }

        piecePanel1.setVisible(false);
        piecePanel2.setVisible(false);
        piecePanel3.setVisible(false);
    }//GEN-LAST:event_applyButtonActionPerformed

    private void searchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyReleased
        String searchText = searchField.getText().trim();
        if (searchText.isEmpty()) {
            clearPanels();  // Limpiar los paneles si no hay texto
            return;
        }

        try {
            // Modificar la consulta para verificar compatibilidad con el vehículo seleccionado
            String query = "SELECT p.*, c.nombre_categoria FROM productos p "
                    + "JOIN categorias c ON p.id_categoria = c.id_categoria "
                    + "JOIN compatibilidad comp ON p.numero_parte = comp.numero_parte "
                    + "WHERE (p.numero_parte = ? OR p.nombre_producto LIKE ?) "
                    + "AND comp.id_auto = ?"; // Filtro de compatibilidad con el vehículo

            try (PreparedStatement statement = conexion.prepareStatement(query)) {
                statement.setString(1, searchText); // Buscar por número de pieza exacto
                statement.setString(2, "%" + searchText + "%"); // Buscar por nombre de pieza similar
                statement.setInt(3, selectedCarID); // Verificar compatibilidad con el ID del vehículo

                clearPanels();  // Limpiar los paneles antes de mostrar nuevos resultados

                try (ResultSet resultSet = statement.executeQuery()) {
                    int i = 0; // Contador de resultados para llenar los 3 paneles
                    while (resultSet.next() && i < 3) {
                        String nombrePieza = resultSet.getString("nombre_producto");
                        String categoria = resultSet.getString("nombre_categoria");
                        double precio = resultSet.getDouble("precio");
                        int stock = resultSet.getInt("stock");
                        String numeroParte = resultSet.getString("numero_parte");

                        // Obtener la imagen como BLOB
                        byte[] imageBytes = resultSet.getBytes("imagen");

                        // Cargar los datos en los paneles correspondientes
                        switch (i) {
                            case 0 -> {
                                name_product1.setText(nombrePieza);
                                category1.setText(categoria);
                                price1.setText("Precio: $" + precio);
                                stocklabel1.setText("Stock: " + stock);
                                part_number1.setText("N° Parte: " + numeroParte);
                                setImage(image1, imageBytes);
                                piecePanel1.setVisible(true);  // Mostrar el panel
                            }
                            case 1 -> {
                                name_product2.setText(nombrePieza);
                                category2.setText(categoria);
                                price2.setText("Precio: $" + precio);
                                stocklabel2.setText("Stock: " + stock);

                                part_number2.setText("N° Parte: " + numeroParte);
                                setImage(image2, imageBytes);
                                piecePanel2.setVisible(true);  // Mostrar el panel
                            }
                            case 2 -> {
                                name_product3.setText(nombrePieza);
                                category3.setText(categoria);
                                price3.setText("Precio: $" + precio);
                                stocklabel3.setText("Stock: " + stock);

                                part_number3.setText("N° Parte: " + numeroParte);
                                setImage(image3, imageBytes);
                                piecePanel3.setVisible(true);  // Mostrar el panel
                            }
                            default -> {
                            }
                        }
                        i++;
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(articleMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_searchFieldKeyReleased

    private void clearPanels() {
        // Limpiar todos los paneles de resultados y ocultarlos
        name_product1.setText("");
        category1.setText("");
        price1.setText("");
        stocklabel1.setText("");
        part_number1.setText("");
        image1.setIcon(null);
        piecePanel1.setVisible(false);  // Ocultar el panel

        name_product2.setText("");
        category2.setText("");
        price2.setText("");
        stocklabel2.setText("");
        part_number2.setText("");
        image2.setIcon(null);
        piecePanel2.setVisible(false);  // Ocultar el panel

        name_product3.setText("");
        category3.setText("");
        price3.setText("");
        stocklabel3.setText("");
        part_number3.setText("");
        image3.setIcon(null);
        piecePanel3.setVisible(false);  // Ocultar el panel
    }

    private void setImage(javax.swing.JLabel label, byte[] imageBytes) {
        if (imageBytes != null) {
            try {
                // Convertir los bytes a un BufferedImage
                ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes);
                BufferedImage bufferedImage = ImageIO.read(bis);
                ImageIcon imageIcon = new ImageIcon(bufferedImage);
                label.setIcon(imageIcon); // Establecer la imagen en el JLabel
            } catch (IOException ex) {
                label.setIcon(null); // En caso de error, no mostrar ninguna imagen
            }
        } else {
            label.setIcon(null); // Si no hay imagen en la base de datos, eliminar cualquier imagen previa
        }
    }

    private void name_product1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_name_product1MouseClicked
        String id = part_number1.getText().replace("N° Parte: ", "");
        detailsArticle dA = new detailsArticle(conexion, id);
        dA.setVisible(true);
    }//GEN-LAST:event_name_product1MouseClicked

    private void name_product2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_name_product2MouseClicked
        String id = part_number2.getText().replace("N° Parte: ", "");
        detailsArticle dA = new detailsArticle(conexion, id);
        dA.setVisible(true);
    }//GEN-LAST:event_name_product2MouseClicked

    private void name_product3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_name_product3MouseClicked
        String id = part_number3.getText().replace("N° Parte: ", "");
        detailsArticle dA = new detailsArticle(conexion, id);
        dA.setVisible(true);
    }//GEN-LAST:event_name_product3MouseClicked

    private void addButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButton1ActionPerformed
        String stock_check = stocklabel1.getText().replace("Stock: ", "");
        int stock_checker = Integer.parseInt(stock_check);

        if (stock_checker == 0) {
            JOptionPane.showMessageDialog(this, "Articulo no disponible por el momento", "Error", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String productName = name_product1.getText();
            String productPart = part_number1.getText().replace("N° Parte: ", "");
            double price = Double.parseDouble(price1.getText().replace("Precio: $", ""));
            addToCart(productPart, productName, price);
        }
    }//GEN-LAST:event_addButton1ActionPerformed

    private void addButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButton2ActionPerformed
        String stock_check = stocklabel2.getText().replace("Stock: ", "");
        int stock_checker = Integer.parseInt(stock_check);
        if (stock_checker == 0) {
            JOptionPane.showMessageDialog(this, "Articulo no disponible por el momento", "Error", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String productName = name_product2.getText();
            String productPart = part_number2.getText().replace("N° Parte: ", "");
            double price = Double.parseDouble(price2.getText().replace("Precio: $", ""));
            addToCart(productPart, productName, price);
        }
    }//GEN-LAST:event_addButton2ActionPerformed

    private void addButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButton3ActionPerformed
        String stock_check = stocklabel3.getText().replace("Stock: ", "");
        int stock_checker = Integer.parseInt(stock_check);
        if (stock_checker == 0) {
            JOptionPane.showMessageDialog(this, "Articulo no disponible por el momento", "Error", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String productName = name_product3.getText();
            String productPart = part_number3.getText().replace("N° Parte: ", "");
            double price = Double.parseDouble(price3.getText().replace("Precio: $", ""));
            addToCart(productPart, productName, price);
        }
    }//GEN-LAST:event_addButton3ActionPerformed

    private void proceedPaymentButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_proceedPaymentButtonActionPerformed
        vendingMenu nextWindow = new vendingMenu(conexion, userID, puesto, (DefaultTableModel) cartTable.getModel());
        nextWindow.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_proceedPaymentButtonActionPerformed

    private void ventasMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventasMenuActionPerformed
        ventasMenu vM = new ventasMenu(conexion);
        vM.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ventasMenuActionPerformed

    private void newCarMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newCarMenuActionPerformed
        addCar aC = new addCar(conexion);
        aC.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_newCarMenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainApp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new mainApp().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu aboutMenu;
    private javax.swing.JButton addButton1;
    private javax.swing.JButton addButton2;
    private javax.swing.JButton addButton3;
    private javax.swing.JButton applyButton;
    private javax.swing.JMenuItem articulosMenu;
    private javax.swing.JComboBox<String> brandComboBox;
    private javax.swing.JLabel brandLabel;
    private javax.swing.JTable cartTable;
    private javax.swing.JLabel category1;
    private javax.swing.JLabel category2;
    private javax.swing.JLabel category3;
    private javax.swing.JMenu developerMenu;
    private javax.swing.JMenuItem empleadosMenu;
    private javax.swing.JLabel image1;
    private javax.swing.JLabel image2;
    private javax.swing.JLabel image3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JMenu logOut;
    private javax.swing.JMenu managerMenu;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JComboBox<String> modelComboBox;
    private javax.swing.JLabel modelLabel;
    private javax.swing.JLabel name_product1;
    private javax.swing.JLabel name_product2;
    private javax.swing.JLabel name_product3;
    private javax.swing.JMenuItem newCarMenu;
    private javax.swing.JPanel panelMainApp;
    private javax.swing.JLabel part_number1;
    private javax.swing.JLabel part_number2;
    private javax.swing.JLabel part_number3;
    private javax.swing.JPanel piecePanel1;
    private javax.swing.JPanel piecePanel2;
    private javax.swing.JPanel piecePanel3;
    private javax.swing.JLabel price1;
    private javax.swing.JLabel price2;
    private javax.swing.JLabel price3;
    private javax.swing.JButton proceedPaymentButton;
    private javax.swing.JTextField searchField;
    private javax.swing.JLabel searchLabel;
    private javax.swing.JLabel stocklabel1;
    private javax.swing.JLabel stocklabel2;
    private javax.swing.JLabel stocklabel3;
    private javax.swing.JLabel subtotalLabel;
    private javax.swing.JMenuItem ventasMenu;
    private javax.swing.JComboBox<String> yearComboBox;
    private javax.swing.JLabel yearLabel;
    // End of variables declaration//GEN-END:variables
}
