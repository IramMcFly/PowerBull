package mainApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class login extends javax.swing.JFrame {

    //Variables especiales
    private static Connection conexion;
    private static String puesto = "";
    private static String userId = "";
    //Variables especiales

    public login() {
        initComponents();
        //this.setExtendedState(JFrame.MAXIMIZED_BOTH); 
        this.setLocationRelativeTo(null);

        loginButton.setEnabled(false);

        ConectorBD("DummySystem", "DummySystem");

    }

    public static Connection ConectorBD(String User, String Password) {

        //Nuevo conector a la base de datos
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/powerbull", User, Password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de Conexion: " + e.getMessage(), "Error de Conexion a la base de datos", 0);

            System.out.println("Error de conexión: " + e.getMessage());

            System.exit(0);
            throw new RuntimeException(e);
        }
        return conexion;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        passwordField = new javax.swing.JPasswordField();
        userField = new javax.swing.JTextField();
        loginButton = new javax.swing.JButton();
        logo = new javax.swing.JLabel();
        userLabel = new javax.swing.JLabel();
        passLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login PowerBull");
        setBackground(new java.awt.Color(255, 255, 255));

        passwordField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                passwordFieldKeyReleased(evt);
            }
        });

        loginButton.setText("Entrar");
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/pblogo.png"))); // NOI18N

        userLabel.setText("Usuario:");

        passLabel.setText("Contrasena:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(271, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(userField, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(userLabel, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(logo, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(passLabel, javax.swing.GroupLayout.Alignment.LEADING)))
                .addContainerGap(273, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(79, Short.MAX_VALUE)
                .addComponent(logo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userLabel)
                .addGap(5, 5, 5)
                .addComponent(userField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(passLabel)
                .addGap(18, 18, 18)
                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(loginButton)
                .addContainerGap(109, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void getData() {
        String password = new String(passwordField.getPassword());
        String username = userField.getText();

        // Consulta para obtener los datos del empleado según el nombre de usuario y la contraseña
        String query = "SELECT e.ID_Empleado, e.nombre, e.apellido_paterno, p.nombre_puesto "
                + "FROM empleados e "
                + "JOIN contrasenas c ON e.ID_Empleado = c.id_empleado "
                + "JOIN puestos p ON e.puesto_id = p.puesto_id "
                + "WHERE e.ID_Empleado = ? AND c.contrasena = ?"; // Verifica que e.nombre sea correcto

        try {
            PreparedStatement preparedStatement = conexion.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            // Verificar si hay resultados
            if (resultSet.next()) {
                userId = resultSet.getString("ID_Empleado");
                puesto = resultSet.getString("nombre_puesto");

                startApp();

            } else {
                JOptionPane.showMessageDialog(null, "Nombre de usuario o contrasena incorrectos.", "Credenciales Incorrectas", 0);
                loginButton.setEnabled(false);
                passwordField.setText("");
            }

        } catch (SQLException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al obtener datos: " + ex.getMessage());
        }

    }

    private void passwordFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_passwordFieldKeyReleased

        if (passwordField.getText().length() == 5 && passwordField.getText().length() < 6) {
            loginButton.setEnabled(true);
        } else {
            loginButton.setEnabled(false);
        }
    }//GEN-LAST:event_passwordFieldKeyReleased

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        getData();
    }//GEN-LAST:event_loginButtonActionPerformed

    private void startApp() {

        try {
            conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(login.class.getName()).log(Level.SEVERE, null, ex);
        }

        if (null == puesto) {
        } else {
            switch (puesto) {
                case "Vendedor" -> {
                    ConectorBD("Ventas", "DummySystem_Ventas_EntryPlug01");
                    mainApp mA = new mainApp(conexion, userId, puesto);
                    mA.setVisible(true);
                    this.dispose();
                }
                case "Gerente" -> {
                    ConectorBD("Gerencia", "DummySystem_Gerencia_EntryPlug00");
                    mainApp mA = new mainApp(conexion, userId, puesto);
                    mA.setVisible(true);
                    this.dispose();
                }
                case "DevOps" -> {
                    ConectorBD("Developer", "DummySystem_DevOps_EntryPlug02");
                    mainApp mA = new mainApp(conexion, userId, puesto);
                    mA.setVisible(true);
                    this.dispose();
                }

                case "No Empleado" ->
                    nocargar();
                default -> {
                }
            }
        }

    }

    private void nocargar() {
        JOptionPane.showMessageDialog(null, "Credenciales no validas para acceder, contacte a un gerente.", "Sin permisos de acceso", 0);
        ConectorBD("DummySystem", "DummySystem");
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new login().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton loginButton;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel passLabel;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JTextField userField;
    private javax.swing.JLabel userLabel;
    // End of variables declaration//GEN-END:variables
}
