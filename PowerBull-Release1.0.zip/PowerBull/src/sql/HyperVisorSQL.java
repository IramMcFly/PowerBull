
package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class HyperVisorSQL {

public Connection conexion;
    
public Connection ConectorBD() {
        //Nuevo conector a la base de datos
        System.out.println("Intentando conectar al servidor");
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/powerbull", "root", "root");
            System.out.println("Conexion exitosa!");
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
            throw new RuntimeException(e);
        }
        return conexion;
    }
    
}


