package sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class queryExecutor {
    
    private Connection conexion;

    public queryExecutor(Connection con) {
        this.conexion = con;
    }

    public String executeCommand(String command) {
        try (Statement stmt = conexion.createStatement()) {
            boolean isSelect = command.trim().toLowerCase().startsWith("select");
            if (isSelect) {
                ResultSet rs = stmt.executeQuery(command);
                StringBuilder result = new StringBuilder();
                int columnCount = rs.getMetaData().getColumnCount();
                while (rs.next()) {
                    for (int i = 1; i <= columnCount; i++) {
                        result.append(rs.getString(i)).append("\t");
                    }
                    result.append("\n");
                }
                rs.close();
                return result.toString();
            } else {
                stmt.execute(command);
                return "Comando ejecutado";
            }
        } catch (SQLException e) {
            System.out.println("Error al ejecutar el comando SQL: " + e.getMessage());
            return "Error al ejecutar el comando: " + e.getMessage();
        }
    }
}
