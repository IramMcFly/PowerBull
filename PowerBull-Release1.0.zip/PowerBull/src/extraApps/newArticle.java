package extraApps;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Statement;
import java.sql.ResultSet;
import mainApp.mainApp;
import screens.articleMenu;

public class newArticle extends javax.swing.JFrame {

    private Connection conexion;
    private BufferedImage selectedImage;
    public int selectedCarID;

    public newArticle(Connection con) {
        this.conexion = con;
        initComponents();
        this.setLocationRelativeTo(null);
        loadCategories(); // Cargar categorías
        loadComboBox();

        brandComboBox.setEnabled(false);
        modelComboBox.setEnabled(false);
        confirmButton.setEnabled(false);

        changeImageButton.setEnabled(false);
        nameField.setEnabled(false);
        categoryComboBox.setEnabled(false);
        saveButton.setEnabled(false);
        stockField.setEnabled(false);
        priceField.setEnabled(false);
    }

    private void loadComboBox() {
        // Cargar años primero
        try {
            String sql = "SELECT DISTINCT anio FROM autos ORDER BY anio";
            Statement stmt = conexion.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                yearComboBox.addItem(String.valueOf(rs.getInt("anio")));

            }
        } catch (SQLException e) {
        }
    }

    private void loadCategories() {
        try {
            PreparedStatement ps = conexion.prepareStatement("SELECT id_categoria, nombre_categoria FROM categorias");
            ResultSet rs = ps.executeQuery();
            categoryComboBox.removeAllItems();
            while (rs.next()) {
                categoryComboBox.addItem(rs.getString("nombre_categoria"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(newArticle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void saveArticle() throws IOException {
        try {
            // Convertir la imagen seleccionada en bytes
            byte[] imageBytes = null;
            if (selectedImage != null) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(selectedImage, "png", baos); // Especificamos el formato de la imagen
                imageBytes = baos.toByteArray(); // Convertimos la imagen a bytes
            }

            // Recuperar la marca y modelo seleccionados
            String selectedBrand = brandComboBox.getSelectedItem().toString(); // Nombre de la marca
            String selectedModel = modelComboBox.getSelectedItem().toString(); // Nombre del modelo
            String selectedYear =  yearComboBox.getSelectedItem().toString();
            
            // Llamar a la función almacenada para generar el número de parte
            String callFunctionQuery = "SELECT GenerarNumeroParte(?, ?, ?, ?) AS numero_parte";
            PreparedStatement ps = conexion.prepareStatement(callFunctionQuery);
            
            //error de conversion de texto a int (por ejemplo
            
            
            ps.setString(1, selectedYear); // Año seleccionado
            ps.setString(2, selectedBrand); // Marca seleccionada
            ps.setString(3, selectedModel); // Modelo seleccionado
            ps.setString(4, nameField.getText()); // Nombre del producto
            ResultSet rs = ps.executeQuery();

            String numeroParte = null;
            if (rs.next()) {
                numeroParte = rs.getString("numero_parte");
            } else {
                JOptionPane.showMessageDialog(this, "Error al generar el número de parte.");
                return;
            }

            // Insertar el artículo en la tabla productos
            String insertProductQuery = "INSERT INTO productos (numero_parte, nombre_producto, precio, stock, id_categoria, imagen) VALUES (?, ?, ?, ?, ?, ?)";
            ps = conexion.prepareStatement(insertProductQuery);
            ps.setString(1, numeroParte); // Número de parte generado
            ps.setString(2, nameField.getText()); // Nombre del producto
            ps.setDouble(3, Double.parseDouble(priceField.getText())); // Precio
            ps.setInt(4, Integer.parseInt(stockField.getText())); // Stock
            ps.setInt(5, categoryComboBox.getSelectedIndex() + 1); // Categoría
            if (imageBytes != null) {
                ps.setBytes(6, imageBytes); // Imagen en bytes
            } else {
                ps.setNull(6, java.sql.Types.BLOB); // Sin imagen
            }
            ps.executeUpdate();

            // Insertar la compatibilidad en la tabla compatibilidad
            String insertCompatibilityQuery = "INSERT INTO compatibilidad (numero_parte, id_auto) VALUES (?, ?)";
            ps = conexion.prepareStatement(insertCompatibilityQuery);
            ps.setString(1, numeroParte); // Número de parte generado
            ps.setInt(2, selectedCarID); // ID del auto seleccionado
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Artículo guardado con éxito y vinculado al vehículo.");
        } catch (SQLException ex) {
            Logger.getLogger(newArticle.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Error al guardar el artículo: " + ex.getMessage());
        } catch (IOException ex) {
            Logger.getLogger(newArticle.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Error al procesar la imagen: " + ex.getMessage());
        }

    }

    public newArticle() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(32767, 32767));
        changeImageButton = new javax.swing.JButton();
        nameLabel = new javax.swing.JLabel();
        nameField = new javax.swing.JTextField();
        priceLabel = new javax.swing.JLabel();
        priceField = new javax.swing.JTextField();
        stockLabel = new javax.swing.JLabel();
        stockField = new javax.swing.JTextField();
        saveButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        ImageLabel = new javax.swing.JLabel();
        categoryLabel = new javax.swing.JLabel();
        categoryComboBox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        yearLabel = new javax.swing.JLabel();
        yearComboBox = new javax.swing.JComboBox<>();
        brandComboBox = new javax.swing.JComboBox<>();
        brandLabel = new javax.swing.JLabel();
        modelComboBox = new javax.swing.JComboBox<>();
        modelLabel = new javax.swing.JLabel();
        confirmButton = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        storeMenu = new javax.swing.JMenu();
        searchMenu = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Nuevo Articulo");

        changeImageButton.setText("Subir Imagen");
        changeImageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeImageButtonActionPerformed(evt);
            }
        });

        nameLabel.setText("Nombre Articulo:");

        priceLabel.setText("Precio:");

        stockLabel.setText("Stock:");

        saveButton.setText("Guardar Articulo");
        saveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveButtonActionPerformed(evt);
            }
        });

        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        ImageLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        categoryLabel.setText("Categoria:");

        categoryComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setText("Imagen");

        yearLabel.setText("Año");

        yearComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearComboBoxActionPerformed(evt);
            }
        });

        brandComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brandComboBoxActionPerformed(evt);
            }
        });

        brandLabel.setText("Marca");

        modelComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modelComboBoxActionPerformed(evt);
            }
        });

        modelLabel.setText("Modelo");

        confirmButton.setText("Confirmar");
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });

        storeMenu.setText("Tienda");
        storeMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                storeMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(storeMenu);

        searchMenu.setText("Buscar Articulo");
        searchMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(searchMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(changeImageButton)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(yearComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(yearLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(brandComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(brandLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(modelComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(confirmButton, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(modelLabel)))
                    .addComponent(cancelButton)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(ImageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(209, 209, 209)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(saveButton)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(categoryLabel)
                                .addComponent(stockField)
                                .addComponent(categoryComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(priceLabel)
                                .addComponent(priceField, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(nameLabel)
                            .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(stockLabel))))
                .addContainerGap(443, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yearLabel)
                    .addComponent(brandLabel)
                    .addComponent(modelLabel))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yearComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(brandComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modelComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirmButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ImageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nameLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(nameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(stockLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(stockField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(categoryLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(categoryComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(priceLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(priceField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(saveButton)))
                .addGap(10, 10, 10)
                .addComponent(changeImageButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                .addComponent(cancelButton)
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void changeImageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeImageButtonActionPerformed
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                selectedImage = ImageIO.read(file);
                ImageIcon icon = new ImageIcon(selectedImage);
                ImageLabel.setIcon(icon);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error al cargar la imagen: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_changeImageButtonActionPerformed

    private void saveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveButtonActionPerformed
        try {
            saveArticle();
            newArticle nA = new newArticle(conexion);
            nA.setVisible(true);
            this.dispose();

        } catch (IOException ex) {
            Logger.getLogger(newArticle.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_saveButtonActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void searchMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchMenuMouseClicked
        articleMenu aM = new articleMenu(conexion);
        aM.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_searchMenuMouseClicked

    private void yearComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearComboBoxActionPerformed
        // Limpiar el ComboBox de marcas y modelos
        brandComboBox.removeAllItems();
        modelComboBox.removeAllItems();

        try {
            String selectedYearString = (String) yearComboBox.getSelectedItem();

            // Asegúrate de que el año no sea nulo y conviértelo a Integer
            if (selectedYearString != null) {
                int selectedYear = Integer.parseInt(selectedYearString);
                String sql = "SELECT DISTINCT m.nombre_marca FROM autos a INNER JOIN marca m ON a.id_marca = m.id_marca WHERE a.anio = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setInt(1, selectedYear);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    brandComboBox.addItem(rs.getString("nombre_marca"));
                }
            }
            brandComboBox.setEnabled(true);
            brandComboBox.setSelectedIndex(-1);
            modelComboBox.setEnabled(false);
            modelComboBox.setSelectedIndex(-1);
        } catch (SQLException | NumberFormatException e) {
            //unuseds
        }

    }//GEN-LAST:event_yearComboBoxActionPerformed

    private void brandComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brandComboBoxActionPerformed
        // Limpiar el ComboBox de modelos
        modelComboBox.removeAllItems();

        try {
            String selectedBrand = (String) brandComboBox.getSelectedItem();
            String selectedYearString = (String) yearComboBox.getSelectedItem();

            // Asegúrate de que el año no sea nulo y conviértelo a Integer
            if (selectedYearString != null) {
                int selectedYear = Integer.parseInt(selectedYearString);
                String sql = "SELECT modelo FROM autos a INNER JOIN marca m ON a.id_marca = m.id_marca WHERE m.nombre_marca = ? AND a.anio = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setString(1, selectedBrand);
                pstmt.setInt(2, selectedYear);
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    modelComboBox.addItem(rs.getString("modelo"));
                }

            }
            modelComboBox.setEnabled(true);
            modelComboBox.setSelectedIndex(-1);
        } catch (SQLException | NumberFormatException e) {

        }
    }//GEN-LAST:event_brandComboBoxActionPerformed

    private void modelComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modelComboBoxActionPerformed
        confirmButton.setEnabled(true);

    }//GEN-LAST:event_modelComboBoxActionPerformed

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
        String selectedYear = (String) yearComboBox.getSelectedItem();
        String selectedBrand = (String) brandComboBox.getSelectedItem();
        String selectedModel = (String) modelComboBox.getSelectedItem();

        if (selectedYear != null && selectedBrand != null && selectedModel != null) {
            try {
                // Consulta para obtener el ID del vehículo basado en el año, marca y modelo seleccionados
                String sql = "SELECT id_auto FROM autos a "
                        + "INNER JOIN marca m ON a.id_marca = m.id_marca "
                        + "WHERE a.anio = ? AND m.nombre_marca = ? AND a.modelo = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setInt(1, Integer.parseInt(selectedYear));
                pstmt.setString(2, selectedBrand);
                pstmt.setString(3, selectedModel);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    int idAuto = rs.getInt("id_auto");

                    // Imprimir y/o guardar el ID
                    System.out.println("ID del Vehículo: " + idAuto);
                    selectedCarID = idAuto;
                    // Aquí podrías hacer otra operación como insertarlo en otra tabla o almacenarlo en una variable global
                    yearComboBox.setEnabled(false);
                    brandComboBox.setEnabled(false);
                    modelComboBox.setEnabled(false);

                    changeImageButton.setEnabled(true);
                    nameField.setEnabled(true);
                    categoryComboBox.setEnabled(true);
                    saveButton.setEnabled(true);
                    stockField.setEnabled(true);
                    priceField.setEnabled(true);
                } else {
                    System.out.println("Vehículo no encontrado.");
                }
            } catch (SQLException e) {
            }
        } else {
            System.out.println("Por favor selecciona año, marca y modelo.");
        }

    }//GEN-LAST:event_confirmButtonActionPerformed

    private void storeMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_storeMenuMouseClicked
        mainApp mA = new mainApp(conexion, "", "Gerente");
        mA.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_storeMenuMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(newArticle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(newArticle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(newArticle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(newArticle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new newArticle().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ImageLabel;
    private javax.swing.JComboBox<String> brandComboBox;
    private javax.swing.JLabel brandLabel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JComboBox<String> categoryComboBox;
    private javax.swing.JLabel categoryLabel;
    private javax.swing.JButton changeImageButton;
    private javax.swing.JButton confirmButton;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JComboBox<String> modelComboBox;
    private javax.swing.JLabel modelLabel;
    private javax.swing.JTextField nameField;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JTextField priceField;
    private javax.swing.JLabel priceLabel;
    private javax.swing.JButton saveButton;
    private javax.swing.JMenu searchMenu;
    private javax.swing.JTextField stockField;
    private javax.swing.JLabel stockLabel;
    private javax.swing.JMenu storeMenu;
    private javax.swing.JComboBox<String> yearComboBox;
    private javax.swing.JLabel yearLabel;
    // End of variables declaration//GEN-END:variables
}
