package extraApps;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class detailsFacture extends javax.swing.JFrame {

    private Connection conexion;

    public detailsFacture(Connection con, String ID) {
        initComponents();
        this.conexion = con;
        cargarDetallesFactura(ID);
        this.setLocationRelativeTo(null);
    }

    public detailsFacture() {

    }

    private void cargarDetallesFactura(String ID) {
        try {
            // Cargar los datos generales de la factura
            String queryFactura = """
            SELECT f.fecha_factura AS fecha, 
                   f.monto_total, 
                   c.razon_social AS cliente
            FROM facturas f
            JOIN clientes_comerciales c ON f.RFC = c.RFC
            WHERE f.factura_id = ?
        """;
            PreparedStatement psFactura = conexion.prepareStatement(queryFactura);
            psFactura.setString(1, ID);
            ResultSet rsFactura = psFactura.executeQuery();

            if (rsFactura.next()) {
                idLabel1.setText(ID);
                clientFLabel.setText(rsFactura.getString("cliente"));
                dateLabel1.setText(rsFactura.getString("fecha"));
                totalLabel1.setText(String.format("$%.2f", rsFactura.getDouble("monto_total")));
            }

            // Cargar los productos de la factura
            String queryProductos = """
            SELECT p.nombre_producto AS producto, 
                   df.numero_parte, 
                   df.monto AS precio
            FROM detalle_facturas df
            JOIN productos p ON df.numero_parte = p.numero_parte
            WHERE df.factura_id = ?
        """;
            PreparedStatement psProductos = conexion.prepareStatement(queryProductos);
            psProductos.setString(1, ID);
            ResultSet rsProductos = psProductos.executeQuery();

            // Modelo de la tabla
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0); // Limpiar datos previos

            int totalProductos = 0;
            while (rsProductos.next()) {
                Object[] row = {
                    rsProductos.getString("producto"),
                    rsProductos.getString("numero_parte"),
                    String.format("$%.2f", rsProductos.getDouble("precio"))
                };
                model.addRow(row);
                totalProductos++;
            }

            totalProductsFLabel.setText(String.valueOf(totalProductos));

        } catch (SQLException ex) {
            Logger.getLogger(detailsFacture.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dateLabel1 = new javax.swing.JLabel();
        totalProductsLabel = new javax.swing.JLabel();
        clientLabel = new javax.swing.JLabel();
        totalProductsFLabel = new javax.swing.JLabel();
        clientFLabel = new javax.swing.JLabel();
        totalLabel = new javax.swing.JLabel();
        totalLabel1 = new javax.swing.JLabel();
        listLabel = new javax.swing.JLabel();
        idLabel = new javax.swing.JLabel();
        idLabel1 = new javax.swing.JLabel();
        cancelButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        dateLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Detalles Factura");

        dateLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        dateLabel1.setText("jLabel1");

        totalProductsLabel.setText("Productos Totales:");

        clientLabel.setText("Cliente:");

        totalProductsFLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        totalProductsFLabel.setText("jLabel2");

        clientFLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        clientFLabel.setText("jLabel1");

        totalLabel.setText("Monto Facturado:");

        totalLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        totalLabel1.setText("jLabel1");

        listLabel.setText("Articulos vendidos: ");

        idLabel.setText("ID de Factura:");

        idLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        idLabel1.setText("jLabel8");

        cancelButton.setText("Volver");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Producto", "Numero de Parte", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        dateLabel.setText("Fecha de la Factura:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cancelButton)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(listLabel)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dateLabel)
                                    .addComponent(totalLabel)
                                    .addComponent(clientLabel)
                                    .addComponent(idLabel))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(idLabel1)
                                    .addComponent(clientFLabel)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(totalLabel1)
                                        .addGap(37, 37, 37)
                                        .addComponent(totalProductsLabel)
                                        .addGap(18, 18, 18)
                                        .addComponent(totalProductsFLabel))
                                    .addComponent(dateLabel1))))
                        .addGap(0, 130, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idLabel)
                    .addComponent(idLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(clientLabel)
                    .addComponent(clientFLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateLabel)
                    .addComponent(dateLabel1))
                .addGap(84, 84, 84)
                .addComponent(listLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(totalLabel)
                    .addComponent(totalLabel1)
                    .addComponent(totalProductsLabel)
                    .addComponent(totalProductsFLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(cancelButton)
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_cancelButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(detailsFacture.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(detailsFacture.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(detailsFacture.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(detailsFacture.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new detailsFacture().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel clientFLabel;
    private javax.swing.JLabel clientLabel;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JLabel dateLabel1;
    private javax.swing.JLabel idLabel;
    private javax.swing.JLabel idLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel listLabel;
    private javax.swing.JLabel totalLabel;
    private javax.swing.JLabel totalLabel1;
    private javax.swing.JLabel totalProductsFLabel;
    private javax.swing.JLabel totalProductsLabel;
    // End of variables declaration//GEN-END:variables
}
