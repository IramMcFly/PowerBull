package extraApps;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import screens.employeeMenu;

public class editEmployee extends javax.swing.JFrame {

    private Connection conexion;

    public editEmployee(Connection con, String ID) {
        this.conexion = con;
        initComponents();
        this.setLocationRelativeTo(null);
        loadEmployeeDetails(ID);
        cargarPuestos();
        this.setTitle("Detalles de: " + employeeName.getText());
    }

    private void cargarPuestos() {
        try {
            String query = "SELECT puesto_id, nombre_puesto FROM puestos";
            PreparedStatement stmt = conexion.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            while (rs.next()) {
                model.addElement(rs.getString("nombre_puesto"));
            }

            puestoCombobox.setModel(model);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar los puestos: " + e.getMessage());
        }
    }

    private void loadEmployeeDetails(String id) {
        String query = "{CALL ObtenerDetallesEmpleado(?)}"; // Llamada al procedimiento almacenado

        try (PreparedStatement ps = conexion.prepareStatement(query)) {
            // Establece el parámetro de entrada
            ps.setString(1, id);

            // Ejecuta la consulta y obtiene los resultados
            ResultSet rs = ps.executeQuery();

            // Si la consulta devuelve resultados
            if (rs.next()) {
                // Construcción del nombre completo
                String nombreCompleto = rs.getString("nombre") + " " + rs.getString("apellido_paterno")
                        + (rs.getString("apellido_materno") != null ? " " + rs.getString("apellido_materno") : "");

                // Asignación de datos a los componentes
                employeeName.setText(nombreCompleto); // Nombre completo
                inDateLabel1.setText(rs.getString("fecha_ingreso")); // Fecha de ingreso
                rfcField.setText(rs.getString("RFC")); // RFC
                nssField.setText(rs.getString("numero_seguro_social")); // NSS
                idLabel1.setText(id); // ID del empleado
                mailField.setText(rs.getString("correo") != null ? rs.getString("correo") : "No registrado"); // Correo

                // Conversión de fecha de nacimiento a Date
                String fechaNacimiento = rs.getString("fecha_nacimiento");
                if (fechaNacimiento != null) {
                    try {
                        Date date = new SimpleDateFormat("yyyy-MM-dd").parse(fechaNacimiento);
                        jDateChooser1.setDate(date); // Establece la fecha en jDateChooser
                    } catch (ParseException e) {
                        Logger.getLogger(editEmployee.class.getName()).log(Level.WARNING, "Error al parsear fecha", e);
                    }
                } else {
                    jDateChooser1.setDate(null); // Limpia la selección si la fecha es nula
                }

                // Selección del puesto en el ComboBox
                String nombrePuesto = rs.getString("nombre_puesto");
                if (nombrePuesto != null) {
                    puestoCombobox.setSelectedItem(nombrePuesto); // Selecciona el puesto correspondiente
                }
            } else {
                Logger.getLogger(editEmployee.class.getName()).log(Level.INFO, "No se encontraron datos para el ID: {0}", id);
            }
        } catch (SQLException ex) {
            // Manejo de excepciones
            Logger.getLogger(editEmployee.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void saveChanges() {
        String query = "{CALL ActualizarEmpleado(?, ?, ?, ?, ?, ?)}"; // Procedimiento actualizado

        try (PreparedStatement ps = conexion.prepareStatement(query)) {
            // Establece los valores obtenidos de los campos
            ps.setString(1, idLabel1.getText()); // ID del empleado
            ps.setString(2, rfcField.getText().trim()); // RFC
            ps.setString(3, nssField.getText().trim()); // NSS
            ps.setString(4, mailField.getText().trim()); // Correo
            ps.setInt(5, puestoCombobox.getSelectedIndex() + 1); // ID del puesto (asumiendo que el índice corresponde al ID)

            // Convertir la fecha seleccionada en el jDateChooser a SQL Date
            java.util.Date fechaNacimiento = jDateChooser1.getDate();
            if (fechaNacimiento != null) {
                ps.setDate(6, new java.sql.Date(fechaNacimiento.getTime()));
            } else {
                ps.setNull(6, java.sql.Types.DATE);
            }

            // Ejecutar el procedimiento almacenado
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Los datos del empleado se actualizaron correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo actualizar los datos del empleado.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(editEmployee.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Error al actualizar los datos del empleado: " + ex.getMessage());
        }
    }

    public editEmployee() {
        //unused
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        employeeName = new javax.swing.JLabel();
        inDateLabel = new javax.swing.JLabel();
        inDateLabel1 = new javax.swing.JLabel();
        puestoLabel = new javax.swing.JLabel();
        rfcLabel = new javax.swing.JLabel();
        nssLabel = new javax.swing.JLabel();
        mailLabel = new javax.swing.JLabel();
        birthDayLabel = new javax.swing.JLabel();
        idLabel = new javax.swing.JLabel();
        idLabel1 = new javax.swing.JLabel();
        cancelButton = new javax.swing.JButton();
        nssField = new javax.swing.JTextField();
        mailField = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        rfcField = new javax.swing.JTextField();
        puestoCombobox = new javax.swing.JComboBox<>();
        saveChangesButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        employeeName.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        employeeName.setText("nombredelempleado + Apellidos");

        inDateLabel.setText("Fecha de Ingreso:");

        inDateLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        inDateLabel1.setText("jLabel1");

        puestoLabel.setText("Puesto:");

        rfcLabel.setText("RFC:");

        nssLabel.setText("NSS:");

        mailLabel.setText("Correo Asignado:");

        birthDayLabel.setText("Fecha de nacimiento:");

        idLabel.setText("ID Asignado:");

        idLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        idLabel1.setText("jLabel8");

        cancelButton.setText("Volver");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        nssField.setText("jTextField1");

        mailField.setText("jTextField2");
        mailField.setToolTipText("Los correos son asignados por el sistema y no deben ser modificados");

        rfcField.setText("jTextField3");

        puestoCombobox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        saveChangesButton.setText("Guardar Cambios");
        saveChangesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveChangesButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(employeeName)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(inDateLabel)
                                        .addGap(18, 18, 18)
                                        .addComponent(inDateLabel1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(idLabel)
                                        .addGap(18, 18, 18)
                                        .addComponent(idLabel1)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(birthDayLabel)
                                    .addComponent(mailLabel)
                                    .addComponent(nssLabel)
                                    .addComponent(rfcLabel)
                                    .addComponent(puestoLabel))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(puestoCombobox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(rfcField)
                                    .addComponent(nssField)
                                    .addComponent(mailField)
                                    .addComponent(jDateChooser1, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cancelButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 243, Short.MAX_VALUE)
                        .addComponent(saveChangesButton)
                        .addGap(140, 140, 140))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(employeeName)
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idLabel)
                    .addComponent(idLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(inDateLabel)
                    .addComponent(inDateLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(puestoLabel)
                    .addComponent(puestoCombobox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rfcLabel)
                    .addComponent(rfcField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nssLabel)
                    .addComponent(nssField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mailLabel)
                    .addComponent(mailField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(birthDayLabel)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 106, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelButton)
                    .addComponent(saveChangesButton))
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void saveChangesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveChangesButtonActionPerformed
        saveChanges();
        employeeMenu eM = new employeeMenu(conexion);
        eM.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_saveChangesButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(editEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new editEmployee().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel birthDayLabel;
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel employeeName;
    private javax.swing.JLabel idLabel;
    private javax.swing.JLabel idLabel1;
    private javax.swing.JLabel inDateLabel;
    private javax.swing.JLabel inDateLabel1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JTextField mailField;
    private javax.swing.JLabel mailLabel;
    private javax.swing.JTextField nssField;
    private javax.swing.JLabel nssLabel;
    private javax.swing.JComboBox<String> puestoCombobox;
    private javax.swing.JLabel puestoLabel;
    private javax.swing.JTextField rfcField;
    private javax.swing.JLabel rfcLabel;
    private javax.swing.JButton saveChangesButton;
    // End of variables declaration//GEN-END:variables
}
