package screens;

import extraApps.detailsVenta;
import java.sql.CallableStatement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import mainApp.mainApp;

public class ventasMenu extends javax.swing.JFrame {

    private Connection conexion;

    public ventasMenu(Connection con) {
        initComponents();
        this.conexion = con;
        
        this.setLocationRelativeTo(null);
        
        
        jTable1.setVisible(false);
        jScrollPane1.setVisible(false);
        totalLabel.setVisible(false);
        totalLabelF.setVisible(false);
        addPopupMenu();
    }

    private void cargarVentasPorDia(java.util.Date fechaSeleccionada) {
        if (fechaSeleccionada == null) {
            totalLabelF.setText("Seleccione una fecha válida");
            return;
        }

        java.sql.Date fechaSQL = new java.sql.Date(fechaSeleccionada.getTime());

        try {
            // Llamada al procedimiento almacenado
            CallableStatement stmt = conexion.prepareCall("{CALL ObtenerVentasPorDia(?)}");
            stmt.setDate(1, fechaSQL);
            boolean hasResult = stmt.execute();

            // Crear modelo para la tabla (sin la columna 'Producto')
            DefaultTableModel modelo = new DefaultTableModel();
            modelo.addColumn("ID Venta");
            modelo.addColumn("Fecha");
            modelo.addColumn("Productos");
            modelo.addColumn("Cantidad Total");
            modelo.addColumn("Total");

            // Cargar las filas de la primera consulta
            if (hasResult) {
                ResultSet rs = stmt.getResultSet();
                while (rs.next()) {
                    modelo.addRow(new Object[]{
                        rs.getInt("venta_id"), // ID de la venta
                        rs.getDate("fecha_venta"), // Fecha de la venta
                        rs.getString("productos"), // Productos concatenados
                        rs.getInt("cantidad_total"), // Cantidad total (sumada)
                        rs.getDouble("total_venta") // Total de la venta (sumado)
                    });
                }
                rs.close();
            }
            double verificador = 0;

            // Cargar el total vendido
            if (stmt.getMoreResults()) {
                ResultSet rsTotal = stmt.getResultSet();
                if (rsTotal.next()) {
                    verificador = rsTotal.getDouble("total_vendido");
                    totalLabelF.setText(String.format("$ %.2f", rsTotal.getDouble("total_vendido")));
                }
                rsTotal.close();
            }

            // Actualizar tabla
            jTable1.setModel(modelo);
            if (verificador == 0) {
                totalLabelF.setText("Ninguna venta registrada");
                jScrollPane1.setVisible(false);
                jTable1.setVisible(false);
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(ventasMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            totalLabelF.setText("Error al cargar datos");
        }
    }

    // Dentro de la clase ventasMenu
    private JPopupMenu popupMenu;

// Llamar este método desde el constructor o después de inicializar la tabla
    private void addPopupMenu() {
        // Crear el PopupMenu
        popupMenu = new JPopupMenu();

        // Crear la opción "Ver detalles de venta"
        JMenuItem verDetallesMenuItem = new JMenuItem("Ver detalles de venta");
        verDetallesMenuItem.addActionListener((ActionEvent e) -> {
            int selectedRow = jTable1.getSelectedRow();
            if (selectedRow != -1) {
                // Obtener el ID de la venta seleccionada
                String idVenta = jTable1.getValueAt(selectedRow, 0).toString();

                // Abrir la ventana detailsVenta
                detailsVenta detalles = new detailsVenta(conexion, idVenta);
                detalles.setVisible(true);
            }
        });

        // Agregar el menú al PopupMenu
        popupMenu.add(verDetallesMenuItem);

        // Añadir un MouseListener a la tabla
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                showPopup(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                showPopup(e);
            }

            private void showPopup(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e) && jTable1.getSelectedRow() != -1) {
                    int row = jTable1.rowAtPoint(e.getPoint());
                    jTable1.setRowSelectionInterval(row, row); // Seleccionar la fila donde se hizo clic
                    popupMenu.show(e.getComponent(), e.getX(), e.getY()); // Mostrar el menú
                }
            }
        });
    }

    public ventasMenu() {

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        dateLabelFinder = new javax.swing.JLabel();
        totalLabel = new javax.swing.JLabel();
        totalLabelF = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        storeMenu = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu de Ventas");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        dateLabelFinder.setText("Mostrando ventas del:");

        totalLabel.setText("Total vendido:");

        totalLabelF.setText("jLabel3");

        jButton1.setText("Aplicar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        storeMenu.setText("Tienda");
        storeMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                storeMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(storeMenu);

        jMenu2.setText("Facturas");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 691, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(totalLabel)
                                .addGap(28, 28, 28)
                                .addComponent(totalLabelF))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(dateLabelFinder)
                                .addGap(18, 18, 18)
                                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(jButton1)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dateLabelFinder)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(totalLabel)
                    .addComponent(totalLabelF))
                .addContainerGap(63, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void storeMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_storeMenuMouseClicked
        mainApp mA = new mainApp(conexion, "", "Gerente");
        this.dispose();
        mA.setVisible(true);
    }//GEN-LAST:event_storeMenuMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cargarVentasPorDia(jDateChooser1.getDate());
        jTable1.setVisible(true);
        jScrollPane1.setVisible(true);
        totalLabel.setVisible(true);
        totalLabelF.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        factureMenu fM = new factureMenu(conexion);
        this.dispose();
        fM.setVisible(true);
    }//GEN-LAST:event_jMenu2MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ventasMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ventasMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ventasMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ventasMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ventasMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel dateLabelFinder;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JMenu storeMenu;
    private javax.swing.JLabel totalLabel;
    private javax.swing.JLabel totalLabelF;
    // End of variables declaration//GEN-END:variables
}
