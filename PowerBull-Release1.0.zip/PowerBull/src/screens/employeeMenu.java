package screens;

import extraApps.editEmployee;
import extraApps.detailsEmployee;
import extraApps.newEmployee;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.swing.DefaultListModel;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;
import mainApp.mainApp;

public class employeeMenu extends javax.swing.JFrame {

    private Connection conexion;

    public employeeMenu(Connection con) {
        initComponents();
        this.conexion = con;
        this.setLocationRelativeTo(null);

        // Configuración del PopupMenu
        configurarPopupMenu();

        // Cargar todos los empleados al inicio
    }

    public void cargarEmpleados(String criterio) {
        DefaultListModel<String> modelo = new DefaultListModel<>();
        try {
            // Consulta SQL con wildcard '%' para buscar por cualquier parte del texto
            String query = "SELECT ID_Empleado, nombre, apellido_paterno, apellido_materno FROM empleados WHERE nombre LIKE ? OR apellido_paterno LIKE ? OR apellido_materno LIKE ? OR ID_Empleado LIKE ?";
            PreparedStatement ps = conexion.prepareStatement(query);
            String searchCriteria = "%" + criterio + "%";
            ps.setString(1, searchCriteria);
            ps.setString(2, searchCriteria);
            ps.setString(3, searchCriteria);
            ps.setString(4, searchCriteria);
            ResultSet rs = ps.executeQuery();

            // Limpiar la lista antes de agregar los nuevos resultados
            modelo.clear();

            while (rs.next()) {
                String id = rs.getString("ID_Empleado");
                String nombre = rs.getString("nombre");
                String apellidoPaterno = rs.getString("apellido_paterno");
                String apellidoMaterno = rs.getString("apellido_materno");
                String empleadoInfo = id + " - " + nombre + " " + apellidoPaterno + " " + apellidoMaterno;
                modelo.addElement(empleadoInfo);
            }

            // Actualizar el modelo de la lista
            employeList.setModel(modelo);

        } catch (SQLException e) {
        }
    }

    private void configurarPopupMenu() {
        // Opción 1: Mostrar detalles del empleado
        JMenuItem printIDItem = new JMenuItem("Detalles del empleado");
        printIDItem.addActionListener((ActionEvent e) -> {
            String selectedEmployee = employeList.getSelectedValue();
            if (selectedEmployee != null) {
                String idEmpleado = selectedEmployee.split(" - ")[0]; // El ID es la primera parte del texto
                detailsEmployee dE = new detailsEmployee(conexion, idEmpleado);
                dE.setVisible(true);
            }
        });

        // Opción 2: Editar detalles del empleado
        JMenuItem editEmployeeItem = new JMenuItem("Editar detalles del empleado");
        editEmployeeItem.addActionListener((ActionEvent e) -> {
            String selectedEmployee = employeList.getSelectedValue();
            if (selectedEmployee != null) {
                String idEmpleado = selectedEmployee.split(" - ")[0]; // El ID es la primera parte del texto
                editEmployee eE = new editEmployee(conexion, idEmpleado);
                eE.setVisible(true);
            }
        });

        // Agregar las opciones al PopupMenu
        jPopupMenu1.add(printIDItem);
        jPopupMenu1.add(editEmployeeItem);

        // Agregar el PopupMenu a la lista de empleados
        employeList.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int index = employeList.locationToIndex(e.getPoint());
                    if (index >= 0) {
                        employeList.setSelectedIndex(index);
                        jPopupMenu1.show(employeList, e.getX(), e.getY());
                    }
                }
            }
        });
    }

    public employeeMenu() {
        //
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        searchLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        employeList = new javax.swing.JList<>();
        searchField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        storeMenu = new javax.swing.JMenu();
        newEmployeeMenu = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menu de Empleados");

        searchLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        searchLabel.setText("Buscar empleado:");

        employeList.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jScrollPane1.setViewportView(employeList);

        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchFieldKeyReleased(evt);
            }
        });

        jLabel1.setText("Empleados");

        storeMenu.setText("Tienda");
        storeMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                storeMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(storeMenu);

        newEmployeeMenu.setText("Nuevo Empleado");
        newEmployeeMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                newEmployeeMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(newEmployeeMenu);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(185, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(searchLabel)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(129, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(102, Short.MAX_VALUE)
                .addComponent(searchLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(84, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyReleased
        String searchText = searchField.getText();
        cargarEmpleados(searchText); // Recargar empleados con el texto actualizado
    }//GEN-LAST:event_searchFieldKeyReleased

    private void newEmployeeMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_newEmployeeMenuMouseClicked
        newEmployee nE = new newEmployee(conexion);
        nE.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_newEmployeeMenuMouseClicked

    private void storeMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_storeMenuMouseClicked
        mainApp mA = new mainApp(conexion, "", "Gerente");
        this.dispose();
        mA.setVisible(true);
    }//GEN-LAST:event_storeMenuMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(employeeMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(employeeMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(employeeMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(employeeMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new employeeMenu().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> employeList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenu newEmployeeMenu;
    private javax.swing.JTextField searchField;
    private javax.swing.JLabel searchLabel;
    private javax.swing.JMenu storeMenu;
    // End of variables declaration//GEN-END:variables
}
