package screens;

import extraApps.detailsFacture;
import extraApps.detailsVenta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import mainApp.mainApp;

public class factureMenu extends javax.swing.JFrame {

    private Connection conexion;

    public factureMenu(Connection con) {
        this.conexion = con;
        initComponents();
        this.setLocationRelativeTo(null);
        addPopupMenu();
    }

    public factureMenu() {

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dateLabelFinder = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        applyButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jMenuBar1 = new javax.swing.JMenuBar();
        storeMenu = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Facturas");

        dateLabelFinder.setText("Mostrando Facturas del:");

        applyButton.setText("Aplicar");
        applyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                applyButtonActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Factura", "Fecha", "Cliente", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        storeMenu.setText("Tienda");
        storeMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                storeMenuMouseClicked(evt);
            }
        });
        jMenuBar1.add(storeMenu);

        jMenu2.setText("Facturas");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(dateLabelFinder)
                .addGap(18, 18, 18)
                .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(applyButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 648, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dateLabelFinder)
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(applyButton))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void storeMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_storeMenuMouseClicked
        mainApp mA = new mainApp(conexion, "", "Gerente");
        this.dispose();
        mA.setVisible(true);
    }//GEN-LAST:event_storeMenuMouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        ventasMenu vM = new ventasMenu(conexion);
        vM.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenu2MouseClicked

    private void applyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_applyButtonActionPerformed
        
        cargarFacturasPorDia(jDateChooser1.getDate());
        System.out.println("Clicked");

    }//GEN-LAST:event_applyButtonActionPerformed

      // Dentro de la clase ventasMenu
    private JPopupMenu popupMenu;

// Llamar este método desde el constructor o después de inicializar la tabla
    private void addPopupMenu() {
        // Crear el PopupMenu
        popupMenu = new JPopupMenu();

        // Crear la opción "Ver detalles de venta"
        JMenuItem verDetallesMenuItem = new JMenuItem("Ver detalles de Factura");
        verDetallesMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = jTable1.getSelectedRow();
                if (selectedRow != -1) {
                    // Obtener el ID de la venta seleccionada
                    String idFactura = jTable1.getValueAt(selectedRow, 0).toString();
                    
                    // Abrir la ventana detailsVenta
                    detailsFacture detalles = new detailsFacture(conexion, idFactura);
                    detalles.setVisible(true);
                }
            }
        });

        // Agregar el menú al PopupMenu
        popupMenu.add(verDetallesMenuItem);

        // Añadir un MouseListener a la tabla
        jTable1.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                showPopup(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                showPopup(e);
            }

            private void showPopup(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e) && jTable1.getSelectedRow() != -1) {
                    int row = jTable1.rowAtPoint(e.getPoint());
                    jTable1.setRowSelectionInterval(row, row); // Seleccionar la fila donde se hizo clic
                    popupMenu.show(e.getComponent(), e.getX(), e.getY()); // Mostrar el menú
                }
            }
        });
    }

    
    private void cargarFacturasPorDia(Date fechaSeleccionada) {
        if (fechaSeleccionada == null) {
            javax.swing.JOptionPane.showMessageDialog(this, "Seleccione una fecha válida.");
            return;
        }

        // Formatear la fecha para MySQL
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String fechaFormateada = sdf.format(fechaSeleccionada);

        try {
            // Preparar la llamada al procedimiento almacenado
            CallableStatement cs = conexion.prepareCall("{CALL ObtenerFacturasPorDia(?)}");
            cs.setString(1, fechaFormateada);

            // Ejecutar y procesar resultados
            ResultSet rs = cs.executeQuery();
            DefaultTableModel model = new DefaultTableModel();

            // Definir columnas para la tabla
            model.addColumn("ID Factura");
            model.addColumn("Fecha");
            model.addColumn("Cliente");
            model.addColumn("Total");

            // Llenar la tabla con los resultados
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("factura_id"),
                    rs.getDate("fecha_factura"),
                    rs.getString("RFC"),
                    rs.getDouble("monto_total")
                });
            }

            // Asignar el modelo a la tabla
            jTable1.setModel(model);
            jTable1.setVisible(true);
            jScrollPane1.setVisible(true);

        } catch (SQLException e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this, "Error al cargar las facturas: " + e.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(factureMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(factureMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(factureMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(factureMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new factureMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton applyButton;
    private javax.swing.JLabel dateLabelFinder;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JMenu storeMenu;
    // End of variables declaration//GEN-END:variables
}
