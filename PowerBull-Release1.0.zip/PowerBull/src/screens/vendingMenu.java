package screens;

import extraApps.comercialAdd;
import java.sql.CallableStatement;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import mainApp.mainApp;

public class vendingMenu extends javax.swing.JFrame {

    private Connection conexion;

    private DefaultTableModel cartTableModel;
    private String IDEmpleado;
    private String puestoEmpleado;

    public vendingMenu(Connection con, String employeeID, String puesto, DefaultTableModel cartTableModel) {
        this.conexion = con;
        this.IDEmpleado = employeeID;
        this.puestoEmpleado = puesto;

        this.cartTableModel = cartTableModel;
        initComponents();
        this.setLocationRelativeTo(null);

        // Configura el modelo en la tabla
        cartTable.setModel(this.cartTableModel);

        // Calcula y muestra el total y el número de artículos
        updateTotal();

        // Opcional: Oculta campos no usados
        clientComboBox.setVisible(false);
        labelRegistro.setVisible(false);
        searchClientField.setVisible(false);
        addPopupMenuToCartTable();
        loadClientComboBox();
        clientComboBox.setEnabled(false);
        clientComboBox.setSelectedIndex(-1);
    }

    private void filterClientComboBox() {
        String filterText = searchClientField.getText().trim().toLowerCase();

        if (filterText.isEmpty()) {
            System.err.println("El campo de búsqueda está vacío.");
            return;
        }

        try {
            // Llamada al procedimiento almacenado
            String callProcedureSQL = "{CALL buscar_clientes(?)}";

            CallableStatement callableStatement = conexion.prepareCall(callProcedureSQL);
            // Configuramos el parámetro del filtro
            callableStatement.setString(1, filterText);

            ResultSet resultSet = callableStatement.executeQuery();

            // Limpia el comboBox antes de actualizarlo
            clientComboBox.removeAllItems();

            while (resultSet.next()) {
                clientComboBox.addItem(resultSet.getString("razon_social"));
            }

            resultSet.close();
            callableStatement.close();

            if (clientComboBox.getItemCount() == 0) {
                System.out.println("No se encontraron coincidencias.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(vendingMenu.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    private void loadClientComboBox() {
        try {
            String query = "SELECT razon_social FROM clientes_comerciales";
            PreparedStatement statement = conexion.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            // Limpia el comboBox antes de cargar los datos
            clientComboBox.removeAllItems();

            while (resultSet.next()) {
                clientComboBox.addItem(resultSet.getString("razon_social"));
            }
            resultSet.close();
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(vendingMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void updateTotal() {
        double total = 0.0;
        int totalArticulos = 0;

        // Verifica que el modelo tiene suficientes filas
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            try {
                // Obtén el precio desde la columna 1 (índice 1)
                double precio = Double.parseDouble(cartTableModel.getValueAt(i, 2).toString()); // Columna 1: Precio
                total += precio; // Suma al total
                totalArticulos++; // Incrementa el número total de artículos
            } catch (NumberFormatException | NullPointerException e) {
                System.err.println("Error procesando fila " + i + ": " + e.getMessage());
            }
        }

        // Actualiza las etiquetas
        totalFLabel.setText(String.format("$%.2f", total));
        productNumberFlabel.setText(String.valueOf(totalArticulos));
    }

    private void addPopupMenuToCartTable() {
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem deleteItem = new JMenuItem("Eliminar");

        deleteItem.addActionListener((ActionEvent e) -> {
            int selectedRow = cartTable.getSelectedRow();
            if (selectedRow != -1) {
                // Elimina la fila seleccionada del modelo
                cartTableModel.removeRow(selectedRow);

                // Actualiza el total
                updateTotal();
            }
        });

        popupMenu.add(deleteItem);

        cartTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int row = cartTable.rowAtPoint(e.getPoint());
                    cartTable.setRowSelectionInterval(row, row);
                    popupMenu.show(cartTable, e.getX(), e.getY());
                }
            }
        });
    }

    public vendingMenu() {
        //unused
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        totalLabel = new javax.swing.JLabel();
        totalFLabel = new javax.swing.JLabel();
        clientComboBox = new javax.swing.JComboBox<>();
        reqFactura = new javax.swing.JCheckBox();
        labelRegistro = new javax.swing.JLabel();
        cardRadioButton = new javax.swing.JRadioButton();
        cashRadioButton = new javax.swing.JRadioButton();
        payMetodLabel = new javax.swing.JLabel();
        productNumberLabel = new javax.swing.JLabel();
        productNumberFlabel = new javax.swing.JLabel();
        searchClientField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        cartTable = new javax.swing.JTable();
        backButton = new javax.swing.JButton();
        finishButton = new javax.swing.JButton();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Completar Venta");

        totalLabel.setText("Total:");

        totalFLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        totalFLabel.setText("label1");

        clientComboBox.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        clientComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        reqFactura.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        reqFactura.setText("Requiere Factura");
        reqFactura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reqFacturaActionPerformed(evt);
            }
        });

        labelRegistro.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        labelRegistro.setForeground(new java.awt.Color(51, 153, 255));
        labelRegistro.setText("No tiene registro?");
        labelRegistro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                labelRegistroMouseClicked(evt);
            }
        });

        buttonGroup1.add(cardRadioButton);
        cardRadioButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cardRadioButton.setText("Tarjeta");
        cardRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cardRadioButtonActionPerformed(evt);
            }
        });

        buttonGroup1.add(cashRadioButton);
        cashRadioButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        cashRadioButton.setText("Efectivo");
        cashRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cashRadioButtonActionPerformed(evt);
            }
        });

        payMetodLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        payMetodLabel.setText("Metodo de Pago");

        productNumberLabel.setText("# de Productos:");

        productNumberFlabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        productNumberFlabel.setText("label1");

        searchClientField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searchClientField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchClientFieldKeyReleased(evt);
            }
        });

        cartTable.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Numero de Parte", "Nombre", "Precio", "Cantidad"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(cartTable);

        backButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        backButton.setText("Volver al Menu Anterior");
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });

        finishButton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        finishButton.setText("Completar Venta");
        finishButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finishButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(totalLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(totalFLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(productNumberLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(productNumberFlabel))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(backButton)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reqFactura)
                            .addComponent(payMetodLabel)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cardRadioButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cashRadioButton))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(labelRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(clientComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(searchClientField, javax.swing.GroupLayout.Alignment.LEADING))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(finishButton)))
                .addContainerGap(197, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(payMetodLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cardRadioButton)
                            .addComponent(cashRadioButton))
                        .addGap(52, 52, 52)
                        .addComponent(reqFactura)
                        .addGap(18, 18, 18)
                        .addComponent(searchClientField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(clientComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(labelRegistro))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(productNumberLabel)
                        .addComponent(productNumberFlabel))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(totalLabel)
                        .addComponent(totalFLabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 147, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(backButton)
                    .addComponent(finishButton))
                .addGap(39, 39, 39))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void reqFacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reqFacturaActionPerformed
        if (reqFactura.isSelected()) {
            clientComboBox.setVisible(true);
            labelRegistro.setVisible(true);
            searchClientField.setVisible(true);
        } else {
            clientComboBox.setVisible(false);
            labelRegistro.setVisible(false);
        }
    }//GEN-LAST:event_reqFacturaActionPerformed

    private void cardRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cardRadioButtonActionPerformed

    }//GEN-LAST:event_cardRadioButtonActionPerformed

    private void cashRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cashRadioButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cashRadioButtonActionPerformed

    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        mainApp mA = new mainApp(conexion, IDEmpleado, puestoEmpleado);
        mA.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backButtonActionPerformed

    private void searchClientFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchClientFieldKeyReleased
        filterClientComboBox();
        if (searchClientField.getText().length() >= 1) {
            clientComboBox.setEnabled(true);
        } else {
            clientComboBox.setEnabled(false);
        }
    }//GEN-LAST:event_searchClientFieldKeyReleased

    private void labelRegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_labelRegistroMouseClicked
        comercialAdd cA = new comercialAdd(conexion);
        cA.setVisible(true);
    }//GEN-LAST:event_labelRegistroMouseClicked

    private void finishButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finishButtonActionPerformed
        try {
            // Limpia y convierte el total
            String totalText = totalFLabel.getText().replace("$", "").trim();
            double total = Double.parseDouble(totalText);
            String productototal = productNumberFlabel.getText();
            int product_total = Integer.parseInt(productototal);

            // Obtén la fecha actual en formato SQL
            java.sql.Date currentDate = new java.sql.Date(System.currentTimeMillis());

            // Prepara la consulta para insertar la venta
            String insertVentaSQL = "INSERT INTO ventas (empleado_id, monto, fecha_venta,productos_vendidos) VALUES (?, ?, ?,?)";
            try (PreparedStatement ventaStatement = conexion.prepareStatement(insertVentaSQL, Statement.RETURN_GENERATED_KEYS)) {
                ventaStatement.setString(1, IDEmpleado);
                ventaStatement.setDouble(2, total);
                ventaStatement.setDate(3, currentDate);
                ventaStatement.setInt(4, product_total);

                // Si requiere factura, obtiene el RFC del cliente seleccionado
                if (reqFactura.isSelected() && clientComboBox.getSelectedIndex() != -1) {
                    String selectedClient = clientComboBox.getSelectedItem().toString();
                    String rfc = fetchRFC(selectedClient);
                }

                // Ejecuta la inserción en la tabla `ventas`
                int rowsAffected = ventaStatement.executeUpdate();

                if (rowsAffected > 0) {
                    // Obtén el ID generado para la venta
                    ResultSet generatedKeys = ventaStatement.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        int ventaID = generatedKeys.getInt(1);

                        // Inserta el detalle de la venta en la tabla `detalle_ventas`
                        insertDetalleVentas(ventaID);

                        // Si se requiere factura, inserta en las tablas `facturas` y `detalle_factura`
                        if (reqFactura.isSelected()) {
                            String selectedClient = clientComboBox.getSelectedItem().toString();
                            String rfc = fetchRFC(selectedClient); // Obtiene el RFC del cliente seleccionado
                            createFactura(ventaID, total, currentDate, rfc);
                        }

                        // Actualiza el stock de los productos vendidos
                        updateProductStock();

                        System.out.println("Venta registrada correctamente.");
                    }
                } else {
                    System.out.println("No se pudo registrar la venta.");
                }

                // Limpia el carrito después de registrar la venta
                mainApp mA = new mainApp(conexion, IDEmpleado, puestoEmpleado);
                mA.setVisible(true);
                this.dispose();

            }

        } catch (NumberFormatException e) {
            System.err.println("Error al convertir el total: " + e.getMessage());
        } catch (SQLException e) {
            Logger.getLogger(vendingMenu.class.getName()).log(Level.SEVERE, null, e);
        }
    }//GEN-LAST:event_finishButtonActionPerformed

    private void insertDetalleVentas(int ventaID) throws SQLException {
        String insertDetalleSQL = "INSERT INTO detalle_ventas (venta_id, numero_parte, precio) VALUES (?, ?, ?)";
        try (PreparedStatement detalleStatement = conexion.prepareStatement(insertDetalleSQL)) {
            for (int i = 0; i < cartTableModel.getRowCount(); i++) {
                String productoID = cartTableModel.getValueAt(i, 0).toString(); // Columna 0: ID del producto
                double precio = Double.parseDouble(cartTableModel.getValueAt(i, 2).toString()); // Columna 2: Precio

                detalleStatement.setInt(1, ventaID);               // Set ID de la venta
                detalleStatement.setString(2, productoID);         // Set número de parte
                detalleStatement.setDouble(3, precio);             // Set precio

                detalleStatement.executeUpdate();  // Ejecuta la inserción
            }
        }

    }

    private void updateProductStock() throws SQLException {
        String callProcedureSQL = "{CALL actualizar_stock(?, ?)}"; // Llamada al procedimiento

// Usamos un mapa para contar las cantidades de cada producto
        Map<String, Integer> productQuantities = new HashMap<>();

// Recorremos las filas del carrito
        for (int i = 0; i < cartTableModel.getRowCount(); i++) {
            String numeroParte = cartTableModel.getValueAt(i, 0).toString(); // Número de parte (columna 0 como String)
            // Si el producto ya está en el mapa, incrementamos su cantidad
            productQuantities.put(numeroParte, productQuantities.getOrDefault(numeroParte, 0) + 1);
        }

        try (CallableStatement callableStatement = conexion.prepareCall(callProcedureSQL)) {
            for (Map.Entry<String, Integer> entry : productQuantities.entrySet()) {
                String numeroParte = entry.getKey(); // Número de parte
                int cantidadVendida = entry.getValue(); // Cantidad vendida

                // Configuramos los parámetros para el procedimiento almacenado
                callableStatement.setString(1, numeroParte);
                callableStatement.setInt(2, cantidadVendida);

                // Ejecutamos la llamada al procedimiento
                callableStatement.execute();
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Manejo de excepciones
        }

    }

    /**
     * Obtiene el RFC del cliente seleccionado.
     */
    private String fetchRFC(String razonSocial) throws SQLException {
        String query = "SELECT rfc FROM clientes_comerciales WHERE razon_social = ?";
        try (PreparedStatement statement = conexion.prepareStatement(query)) {
            statement.setString(1, razonSocial);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("rfc");
                }
            }
        }
        return null;
    }

    /**
     * Inserta el detalle de la venta en la tabla `detalle_ventas`.
     */
    /**
     * Crea la factura y registra sus detalles.
     */
    private void createFactura(int ventaID, double total, java.sql.Date fecha, String rfc) throws SQLException {
        String insertFacturaSQL = "INSERT INTO facturas (venta_id, fecha_factura, monto_total, RFC,total_productos) VALUES (?, ?, ?, ?,?)";
        try (PreparedStatement facturaStatement = conexion.prepareStatement(insertFacturaSQL, Statement.RETURN_GENERATED_KEYS)) {
            facturaStatement.setInt(1, ventaID);
            facturaStatement.setDate(2, fecha);
            facturaStatement.setDouble(3, total);
            
            
            String productototal = productNumberFlabel.getText();
            int product_total = Integer.parseInt(productototal);
            facturaStatement.setInt(5, product_total );
            // Añade el RFC si está disponible; de lo contrario, inserta NULL
            if (rfc != null) {
                facturaStatement.setString(4, rfc);
            } else {
                facturaStatement.setNull(4, java.sql.Types.VARCHAR);
            }

            
            // Inserta la factura
            facturaStatement.executeUpdate();

            // Obtiene el ID generado para la factura
            ResultSet generatedKeys = facturaStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                int facturaID = generatedKeys.getInt(1);

                // Inserta el detalle de la factura
                insertDetalleFactura(facturaID);
            }
        }
    }

    /**
     * Inserta los detalles de la factura en la tabla `detalle_factura`.
     */
    private void insertDetalleFactura(int facturaID) throws SQLException {
        String insertDetalleFacturaSQL = "INSERT INTO detalle_facturas (factura_id, numero_parte, monto) VALUES (?, ?, ?)";
        try (PreparedStatement detalleFacturaStatement = conexion.prepareStatement(insertDetalleFacturaSQL)) {
            for (int i = 0; i < cartTableModel.getRowCount(); i++) {
                String productoID = cartTableModel.getValueAt(i, 0).toString(); // Columna 0: ID del producto
                double precio = Double.parseDouble(cartTableModel.getValueAt(i, 2).toString()); // Columna 2: Precio

                detalleFacturaStatement.setInt(1, facturaID);
                detalleFacturaStatement.setString(2, productoID);
                detalleFacturaStatement.setDouble(3, precio);

                detalleFacturaStatement.executeUpdate();
            }
        }
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(vendingMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(vendingMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(vendingMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(vendingMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vendingMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backButton;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JRadioButton cardRadioButton;
    private javax.swing.JTable cartTable;
    private javax.swing.JRadioButton cashRadioButton;
    private javax.swing.JComboBox<String> clientComboBox;
    private javax.swing.JButton finishButton;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelRegistro;
    private javax.swing.JLabel payMetodLabel;
    private javax.swing.JLabel productNumberFlabel;
    private javax.swing.JLabel productNumberLabel;
    private javax.swing.JCheckBox reqFactura;
    private javax.swing.JTextField searchClientField;
    private javax.swing.JLabel totalFLabel;
    private javax.swing.JLabel totalLabel;
    // End of variables declaration//GEN-END:variables
}
